import Image from 'next/image'
import { cn } from '@/lib/utils/cn'

/**
 * Auth split layout — verified from Figma node 4:988 (sign in)
 *
 * LEFT  (834px): white bg (#f7f7f7), logo top-left, form slot
 * RIGHT (606px): blue gradient panel, lock icons, splash + tagline, carousel dots
 *
 * Gradient: #003BDF (top) → #688EEC (mid) → #E9F4FC (bottom)
 * Lock icons: public/images/auth/ (lock-fill.svg, lock-thin.svg)
 * Splash: public/images/auth/splash.png
 */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-auth-left-bg">

      {/* ── Left panel ───────────────────────────────────────────────────────── */}
      <div
        className={cn(
          'relative flex-1 lg:min-h-screen',
          'bg-auth-left-bg flex flex-col overflow-y-auto'
        )}
      >
        {/* Logo */}
        <div className="absolute top-9 start-[46px] p-[10px] z-10">
          <span
            className="font-righteous text-[40px] leading-none font-normal bg-clip-text text-transparent select-none"
            style={{
              backgroundImage:
                'linear-gradient(90deg, rgba(0,59,223,0.9) 43.75%, rgba(131,163,239,0.96) 87.019%, #e9f4fc 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Cykemet
          </span>
        </div>

        {/* Form slot — starts at 163px on desktop, 96px on mobile */}
        <div className="flex flex-col items-center w-full pt-24 lg:pt-[163px] pb-16 px-6 lg:px-[86px]">
          <div className="w-full max-w-[662px]">
            {children}
          </div>
        </div>
      </div>

      {/* ── Right panel ──────────────────────────────────────────────────────── */}
      <div
        className="hidden lg:block lg:w-[606px] lg:min-h-screen relative overflow-hidden shrink-0"
        style={{
          background: 'linear-gradient(180deg, #003bdf 0%, #688eec 105.65%, #e9f4fc 131.01%)',
        }}
      >
        {/* Lock fill — small, top-left (partially outside) */}
        <div className="absolute -left-[52px] -top-[33px] size-[171px] flex items-center justify-center">
          <div style={{ transform: 'rotate(-13.42deg)' }}>
            <Image
              src="/images/auth/lock-fill.svg"
              alt=""
              width={142}
              height={142}
              className="object-contain"
              unoptimized
            />
          </div>
        </div>

        {/* Lock fill — large, bottom-right (partially outside) */}
        <div className="absolute right-[-60px] bottom-[27px] size-[190px] flex items-center justify-center">
          <div style={{ transform: 'rotate(-13.42deg)' }}>
            <Image
              src="/images/auth/lock-fill.svg"
              alt=""
              width={158}
              height={158}
              className="object-contain"
              unoptimized
            />
          </div>
        </div>

        {/* Lock light — large, left-center (clips outside) */}
        <div className="absolute -left-[170px] top-[380px] width-[193px] height-[249px] flex items-center justify-center overflow-hidden" style={{ transform: 'rotate(14.1deg)' }}> 
          <div>
            <Image
              src="/images/auth/lock-thin.svg"
              alt=""
              width={332}
              height={332}
              className="object-contain"
              unoptimized
            />
          </div>
        </div>

        {/* Lock light — small, bottom-left */}
        <div className="absolute -left-[118px] -bottom-[92px] size-[280px] flex items-center justify-center overflow-hidden">
          <div style={{ transform: 'rotate(-19.76deg)' }}>
            <Image
              src="/images/auth/lock-stroke.svg"
              alt=""
              width={219}
              height={219}
              className="object-contain"
              unoptimized
            />
          </div>
        </div>

        {/* Lock light — large, top-right (clips outside) */}
        <div className="absolute -right-[201px] -top-[29px] size-[402px] flex items-center justify-center overflow-hidden">
          <div style={{ transform: 'rotate(14.1deg)' }}>
            <Image
              src="/images/auth/lock-thin.svg"
              alt=""
              width={332}
              height={332}
              className="object-contain"
              unoptimized
            />
          </div>
        </div>

        {/* Splash image + tagline block */}
        <div className="absolute left-1/2 -translate-x-1/2 top-[277px] flex flex-col gap-[25px] items-center w-[511px]">
          {/* Dashboard screenshot */}
          <div className="relative w-[511px] h-[364px] rounded-[20px] overflow-hidden shadow-modal">
            <Image
              src="/images/auth/splash.png"
              alt="CyKemet.com platform preview"
              fill
              className="object-cover"
              priority
              unoptimized
            />
          </div>

          {/* Tagline */}
          <div className="flex flex-col gap-5 items-center text-center text-white w-[488px]">
            <p className="text-[36px] font-semibold leading-tight">
              The security you trust
            </p>
            <p className="text-[20px] font-thin leading-relaxed">
              Discover vulnerabilities, submit reports, and get rewarded for real impact
            </p>
          </div>
        </div>

        {/* Carousel dots */}
        <div className="absolute left-1/2 -translate-x-1/2 top-[813px] flex gap-[6px] items-center">
          <div className="h-[6px] w-[34px] rounded-[8px] bg-dot-active" />
          <div className="h-[6px] w-[20px] rounded-[8px] bg-dot-inactive" />
          <div className="h-[6px] w-[20px] rounded-[8px] bg-dot-inactive" />
        </div>
      </div>

    </div>
  )
}
