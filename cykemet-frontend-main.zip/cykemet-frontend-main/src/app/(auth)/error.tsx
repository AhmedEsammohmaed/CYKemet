'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import { AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface AuthErrorProps {
  error: Error & { digest?: string }
  reset: () => void
}

/**
 * Shared error boundary for all (auth) routes.
 * Renders inside the left panel of AuthLayout.
 */
export default function AuthError({ error, reset }: AuthErrorProps) {
  useEffect(() => {
    console.error('[auth error]', error)
  }, [error])

  return (
    <div className="flex flex-col items-center gap-8 text-center">
      <div className="size-20 rounded-full bg-error-50 flex items-center justify-center">
        <AlertTriangle size={36} className="text-error-500" />
      </div>

      <div className="flex flex-col gap-3">
        <h2 className="text-h1 font-semibold text-content-500">Something went wrong</h2>
        <p className="text-body-1 text-grey-main max-w-[380px]">
          {error.message || 'An unexpected error occurred. Please try again.'}
        </p>
      </div>

      <div className="flex flex-col gap-3 w-full max-w-[320px]">
        <button
          type="button"
          onClick={reset}
          className={cn(
            'w-full h-[60px] rounded-card bg-primary-500 text-white',
            'text-h3 font-medium hover:opacity-90 active:opacity-80 transition-opacity'
          )}
        >
          Try again
        </button>
        <Link
          href="/login"
          className="text-body-1 text-grey-main underline hover:text-primary-500 transition-colors"
        >
          Back to sign in
        </Link>
      </div>
    </div>
  )
}
