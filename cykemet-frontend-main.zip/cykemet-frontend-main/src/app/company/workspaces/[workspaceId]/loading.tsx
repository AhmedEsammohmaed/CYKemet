export default function Loading() {
  return (
    <div className="flex flex-col gap-6 animate-pulse">
      {/* Stat cards skeleton */}
      <div className="flex gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex-1 bg-white rounded-card h-[84px]" />
        ))}
      </div>

      {/* Toolbar skeleton */}
      <div className="flex items-center gap-[43px]">
        <div className="flex-1 h-[46px] bg-white rounded-[10px]" />
        <div className="flex gap-3">
          <div className="w-[180px] h-[46px] bg-white rounded-card" />
          <div className="w-[180px] h-[46px] bg-white rounded-card" />
        </div>
      </div>

      {/* Two-column skeleton */}
      <div className="flex gap-8 items-start">
        <div className="flex-1 bg-white rounded-card p-[22px]">
          <div className="h-5 w-full bg-secondary-50 rounded mb-6" />
          <div className="flex flex-col gap-8">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-4 bg-secondary-50 rounded" />
            ))}
          </div>
        </div>
        <div className="w-[278px] shrink-0 bg-white rounded-card h-[468px]" />
      </div>
    </div>
  )
}
