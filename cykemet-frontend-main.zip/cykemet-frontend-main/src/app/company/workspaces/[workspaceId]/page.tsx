'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useParams, useRouter } from 'next/navigation'
import {
  CircleCheck, ClipboardPaste, ScanEye, CheckCheck,
  Search, CircleAlert, ArrowUpDown, ChevronDown,
  ExternalLink, UserRoundPlus, UserRoundMinus,
} from 'lucide-react'
import { useNav } from '@/lib/context/NavContext'
import { SeverityBadge } from '@/components/ui/SeverityBadge'
import { CreateWorkspaceModal } from '@/components/company/CreateWorkspaceModal'
import { cn } from '@/lib/utils/cn'
import { mockWorkspaceDetails } from '@/lib/mock/company'
import type { WorkspaceReportStatus, WorkspaceMember, WorkspaceReport } from '@/types'

// ─── Stat Card ────────────────────────────────────────────────────────────────

interface StatCardProps {
  icon: React.ElementType
  label: string
  value: number
}

function StatCard({ icon: Icon, label, value }: StatCardProps) {
  return (
    <div className="flex-1 bg-white rounded-card h-[84px] flex items-center justify-center gap-[11px] px-[25px] py-[18px]">
      <div className="size-[70px] rounded-[35px] bg-secondary-50 flex items-center justify-center shrink-0">
        <Icon size={28} className="text-primary-500" />
      </div>
      <div className="flex flex-col gap-1">
        <p className="font-medium text-body-md text-grey-main">{label}</p>
        <p className="font-bold text-h1 text-black">{value}</p>
      </div>
    </div>
  )
}

// ─── Report status badge ──────────────────────────────────────────────────────

const STATUS_CONFIG: Record<WorkspaceReportStatus, {
  label: string; bg: string; border: string; text: string
}> = {
  new:       { label: 'New',       bg: 'bg-[rgba(233,244,252,0.66)]', border: 'border-primary-500/66', text: 'text-primary-500'  },
  resolved:  { label: 'Resolved',  bg: 'bg-[rgba(169,239,195,0.66)]', border: 'border-success-500',    text: 'text-success-500'  },
  triaged:   { label: 'Triaged',   bg: 'bg-[rgba(253,225,155,0.66)]', border: 'border-warning-500',    text: 'text-warning-500'  },
  in_review: { label: 'In review', bg: 'bg-[rgba(255,113,4,0.66)]',   border: 'border-severity-high',  text: 'text-[#ef6800]'    },
}

function ReportStatusBadge({ status }: { status: WorkspaceReportStatus }) {
  const { label, bg, border, text } = STATUS_CONFIG[status]
  return (
    <span
      className={cn(
        'inline-flex items-center justify-center h-[22px] px-[11px] rounded-[18px] border',
        'font-medium text-label-xs whitespace-nowrap',
        bg, border, text
      )}
    >
      {label}
    </span>
  )
}

// ─── Filter pill ──────────────────────────────────────────────────────────────

interface FilterPillProps {
  icon: React.ElementType
  label: string
}

function FilterPill({ icon: Icon, label }: FilterPillProps) {
  return (
    <div className="flex items-center justify-center gap-[40px] bg-white h-[46px] px-[18px] rounded-card w-[180px] shrink-0">
      <div className="flex items-center gap-1.5">
        <Icon size={20} className="text-grey-main shrink-0" />
        <span className="font-medium text-h5 text-grey-main">{label}</span>
      </div>
      <ChevronDown size={16} className="text-grey-main" />
    </div>
  )
}

// ─── Member row ───────────────────────────────────────────────────────────────

function MemberRow({ member }: { member: WorkspaceMember }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-[13px]">
        {/* Avatar with initial */}
        <div className="size-[47px] rounded-full bg-secondary-50 flex items-center justify-center shrink-0">
          <span className="font-semibold text-primary-500 text-[20.634px] leading-none">
            {member.initials}
          </span>
        </div>
        <div className="flex flex-col gap-0.5">
          <p className="font-medium text-h5 text-content-500 leading-normal">{member.name}</p>
          <p className="font-medium text-body-md text-grey-main leading-normal">{member.role}</p>
        </div>
      </div>
      {/* Mock remove — no-op */}
      <button type="button" aria-label="Remove member" className="text-grey-main hover:text-content-500 transition-colors">
        <UserRoundMinus size={22} />
      </button>
    </div>
  )
}

// ─── Report row ───────────────────────────────────────────────────────────────

function ReportRow({ report, workspaceId }: { report: WorkspaceReport; workspaceId: string }) {
  return (
    <tr>
      {/* Title + external link */}
      <td className="py-4 pe-4">
        {/* TODO: /company/workspaces/[workspaceId]/reports/[reportId] not yet built */}
        <Link
          href={`/company/workspaces/${workspaceId}/reports/${report.id}`}
          className="inline-flex items-center gap-1.5 font-medium text-body-lg text-content-500 hover:text-primary-500 transition-colors"
        >
          {report.title}
          <ExternalLink size={18} className="shrink-0" />
        </Link>
      </td>
      {/* Status */}
      <td className="py-4 pe-4">
        <ReportStatusBadge status={report.status} />
      </td>
      {/* Researcher */}
      <td className="py-4 pe-4">
        <span className="font-medium text-body-lg text-content-500">{report.researcher}</span>
      </td>
      {/* Severity */}
      <td className="py-4 pe-4">
        <SeverityBadge severity={report.severity} />
      </td>
      {/* Date */}
      <td className="py-4">
        <span className="font-medium text-body-lg text-grey-main">{report.date}</span>
      </td>
    </tr>
  )
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function WorkspaceDetailPage() {
  const { workspaceId } = useParams<{ workspaceId: string }>()
  const router = useRouter()
  const { setTitle } = useNav()
  const [search, setSearch] = useState('')
  const [modalOpen, setModalOpen] = useState(false)

  const workspace = mockWorkspaceDetails.find((w) => w.id === workspaceId)

  useEffect(() => {
    if (!workspace) {
      router.replace('/company/workspaces')
    }
  }, [workspace, router])

  useEffect(() => {
    if (workspace) setTitle(workspace.name)
  }, [workspace, setTitle])

  if (!workspace) return null

  const filteredReports = workspace.reports.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="flex flex-col gap-6">
      <CreateWorkspaceModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />

      {/* Stat cards */}
      <div className="flex gap-6">
        <StatCard icon={CircleCheck}    label="New reports"      value={workspace.stats.newReports} />
        <StatCard icon={ClipboardPaste} label="Triaged reports"  value={workspace.stats.triaged}    />
        <StatCard icon={ScanEye}        label="In review reports" value={workspace.stats.inReview}  />
        <StatCard icon={CheckCheck}     label="Resolved reports" value={workspace.stats.resolved}   />
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-[43px]">
        {/* Search */}
        <div className="flex-1 flex items-center gap-1.5 bg-white h-[46px] px-4 rounded-[10px]">
          <Search size={24} className="text-grey-main shrink-0" />
          <input
            type="text"
            placeholder="Search a report here"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent outline-none font-medium text-h5 text-content-500 placeholder:text-grey-main"
          />
        </div>
        {/* Filter pills */}
        <div className="flex items-center gap-3">
          <FilterPill icon={CircleAlert} label="Status"  />
          <FilterPill icon={ArrowUpDown} label="Sort by" />
        </div>
      </div>

      {/* Two-column layout */}
      <div className="flex gap-8 items-start">

        {/* LEFT — Reports table */}
        <div className="flex-1 bg-white rounded-card p-[22px]">
          <table className="w-full table-auto">
            <thead>
              <tr>
                <th className="pb-6 text-start font-medium text-body-md text-grey-main">Report title</th>
                <th className="pb-6 text-start font-medium text-body-md text-grey-main">Status</th>
                <th className="pb-6 text-start font-medium text-body-md text-grey-main">Researcher</th>
                <th className="pb-6 text-start font-medium text-body-md text-grey-main">Severity</th>
                <th className="pb-6 text-start font-medium text-body-md text-grey-main">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-transparent">
              {filteredReports.map((report) => (
                <ReportRow key={report.id} report={report} workspaceId={workspaceId} />
              ))}
              {filteredReports.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center font-medium text-body-md text-grey-main">
                    No reports match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* RIGHT — Members panel */}
        <div className="w-[278px] shrink-0 bg-white rounded-card pt-[22px] pb-[29px] px-[22px]">
          <div className="flex flex-col gap-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <span className="font-semibold text-h3 text-black">
                Member ({workspace.members.length})
              </span>
              {/* Wire to CreateWorkspaceModal — mock add member */}
              <button
                type="button"
                aria-label="Add member"
                onClick={() => setModalOpen(true)}
                className="text-grey-main hover:text-content-500 transition-colors"
              >
                <UserRoundPlus size={22} />
              </button>
            </div>
            {/* Member list */}
            <div className="flex flex-col gap-8">
              {workspace.members.map((member) => (
                <MemberRow key={member.id} member={member} />
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
